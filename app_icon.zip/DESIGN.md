---
name: Toddler Magic World
colors:
  surface: '#f7f9fc'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#3f484c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6f787d'
  outline-variant: '#bfc8cd'
  surface-tint: '#0c6780'
  primary: '#0c6780'
  on-primary: '#ffffff'
  primary-container: '#87ceeb'
  on-primary-container: '#005870'
  inverse-primary: '#89d0ed'
  secondary: '#316b00'
  on-secondary: '#ffffff'
  secondary-container: '#7cfc01'
  on-secondary-container: '#347000'
  tertiary: '#705d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#e6c200'
  on-tertiary-container: '#605000'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#baeaff'
  primary-fixed-dim: '#89d0ed'
  on-primary-fixed: '#001f29'
  on-primary-fixed-variant: '#004d62'
  secondary-fixed: '#82ff1a'
  secondary-fixed-dim: '#6ee000'
  on-secondary-fixed: '#0a2000'
  on-secondary-fixed-variant: '#245100'
  tertiary-fixed: '#ffe16d'
  tertiary-fixed-dim: '#e9c400'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#f7f9fc'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Quicksand
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Quicksand
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Quicksand
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  title-md:
    fontFamily: Quicksand
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Quicksand
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  label-bold:
    fontFamily: Quicksand
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  touch-target-min: 64px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 40px
  card-gap: 16px
---

## Brand & Style

This design system is built for the wonder and curiosity of toddlers aged 1–5. The personality is **Joyful, Safe, and Enchanting**, mirroring the high-quality feel of a premium animated series. 

The aesthetic blends **Tactile Skeuomorphism** with **Soft Minimalism**. Every element is designed to feel "squishy" and touchable, reducing the barrier between the physical and digital world for developing motor skills. We utilize "Claymorphism" and "Glassmorphism" to create a sense of depth, using soft internal shadows and glossy highlights to make buttons look like physical toys. The emotional goal is to evoke a sense of accomplishment through magical feedback loops and vibrant, friendly visuals.

## Colors

The palette is rooted in nature and play. 
- **Sky Blue (#87CEEB):** Used for primary backgrounds and safe exploration areas.
- **Grass Green (#7CFC00):** Used for "Go" actions and growth-related success moments.
- **Sunshine Yellow (#FFD700):** Primary highlight color for rewards and stars.
- **Bubblegum Pink & Lavender:** Secondary accents used to differentiate game categories or UI sub-elements.
- **Creamy Neutral (#FFF9E6):** Instead of pure white, we use a warm off-white for panels to reduce eye strain and feel more organic.

Gradients should be used generously, moving from the base color to a slightly lighter, more vibrant tint to simulate 3D lighting.

## Typography

We use **Quicksand** exclusively for its rounded terminals and friendly, open character. It is highly legible for early learners and feels soft rather than clinical.

- **Weight Usage:** Bold and Semibold weights are prioritized to ensure high contrast and readability against vibrant backgrounds.
- **Readability:** All text should have a subtle dark-blue or dark-purple text shadow (low blur) when placed on colored backgrounds to ensure it pops.
- **Scaling:** For mobile devices, we maintain large font sizes (minimum 18px) to ensure parents and children can easily identify labels.

## Layout & Spacing

The layout is **Fluid and Contextual**, moving away from rigid grids to allow for organic, floating elements. 

- **Safe Zones:** Generous margins (20px+) are maintained at the edges of the screen to prevent accidental touches near the device bezel.
- **Touch Targets:** A strict minimum of 64x64px for all interactive elements to accommodate "fat-finger" interactions from toddlers.
- **Vertical Rhythm:** Content is grouped in "islands" or rounded cards, with a 24px gutter between major sections to prevent visual clutter.
- **Reflow:** On tablets, the layout expands from a single column to a 2 or 3-column grid of oversized activity cards.

## Elevation & Depth

Hierarchy is achieved through **Soft 3D Volume (Claymorphism)** rather than traditional drop shadows.

- **The "Squish" Factor:** Interactive elements use a combination of a 4px bottom border (darker shade of the button color) and a top-inner white glow to create a 3D "pushed" look.
- **Floating Layer:** The main activity area sits on a large, rounded container with a deep, soft ambient shadow (Color: `RGBA(0,0,0,0.08)`, Blur: 30px).
- **Active State:** When pressed, buttons should physically move down 4px (eliminating the bottom border) to provide instant tactile feedback.
- **Gloss:** High-priority buttons feature a diagonal white-to-transparent gradient overlay at 20% opacity to simulate a plastic sheen.

## Shapes

The design system avoids sharp corners entirely.
- **Pill-shaped (Level 3):** All buttons and small labels are fully rounded (pill-shaped) to feel friendly and safe.
- **Organic Blobs:** Containers and background masks should use slightly irregular, hand-drawn-style curves rather than perfect geometric circles to feel more like an animated world.
- **Icons:** All iconography must have rounded caps and a minimum stroke weight of 4px.

## Components

### Buttons
Buttons are large, chunky, and colorful. Each button must have a contrasting "3D base" color. Primary actions are Green, secondary are Blue or Pink.

### Reward Badges
- **Stars:** High-gloss yellow with a rotating "sparkle" animation.
- **Rainbows:** Multi-gradient arcs used for progress tracking or streaks.
- **Hearts:** Soft, pulsating pink shapes used for lives or "likes" of favorite activities.

### Activity Cards
Cards feature a large central icon or 3D character, a bold title underneath, and a subtle "glass" overlay effect on the bottom third for the label.

### Progress Bars
Oversized "caterpillar" tracks. The progress fill is a vibrant gradient with a "bubble" pattern inside, making the bar feel like a liquid-filled tube.

### Modals & Dialogs
Instead of "X" buttons, use large "Home" icons or "Back" arrows in the top corners. Dialogs should bounce into view with an "elastic" easing function.

### Checkboxes & Radios
Replaced by "Sticker Slots." When an item is selected, a colorful sticker "slaps" onto the slot with a satisfying sound effect and particle burst.